const tunnel = require('tunnel-ssh');
const { MongoClient } = require('mongodb');
const path = require('path');
 
const sshConfig = {
  username: 'boxdevchtftp',
  host: '44.193.9.8',
  password: 'o0ad454ah5d3M4ePK8',
  port: 22,
  dstHost: 'boxlty-dev.cluster-cuxrfj98o5ja.us-east-1.docdb.amazonaws.com',
  dstPort: 27017,
  localHost: '127.0.0.1',
  localPort: 27017,
};
 
const caFilePath = path.resolve(__dirname, 'global-bundle.pem');
 
const uri = `mongodb://boxltydev:Nju10KlzpAjUqMyAvPP@127.0.0.1:27017/?tls=true&tlsCAFile=${caFilePath}&tlsAllowInvalidHostnames=true&retryWrites=false&readPreference=secondaryPreferred&directConnection=true`;
 
function createTunnel(config) {
  return new Promise((resolve, reject) => {
    tunnel(config, (err, server) => {
      if (err) return reject(err);
      resolve(server);
    });
  });
}
 
async function run() {
  let server;
  try {
    console.log('Connecting SSH tunnel...');
    server = await createTunnel(sshConfig);
    console.log('SSH tunnel established.');
 
    const client = new MongoClient(uri);
    await client.connect();
    console.log('Connected to DocumentDB via SSH tunnel.');
 
    const db = client.db('boxlty');
    const collection = db.collection('users');
 
    const result = await collection.insertOne({
      name: 'John Doe',
      age: 30,
      createdAt: new Date(),
    });
 
    console.log('Inserted document ID:', result.insertedId);
 
    await client.close();
    server.close();
    console.log('Closed connections.');
  } catch (err) {
    console.error('Error:', err);
    if (server) server.close();
  }
}
 
run();